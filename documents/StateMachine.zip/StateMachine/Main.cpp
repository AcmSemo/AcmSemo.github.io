#include <iostream>
#include "StateMachine.h"
#include <string>
#include <map>

class ChildOfStateMachine: public StateMachine {
	public:
		float x;
		float y;
		float health;
		ChildOfStateMachine(float x, float y) {
			this->x = x; this->y = y;
		} //pass by value constructor
		void CheckState(); //CheckState() override declared
		void SetIdle(); //adding functions for the logic of our states
		void SetChasing();
		void SetRetreating();
};

struct Enemy {
	float x;
	float y;
	Enemy() = default;
};

Enemy enemy;
std::map<float, float> origin;

int main(int argc, char** argv) {
	ChildOfStateMachine sm(0,0);
	sm.SetState(sm.IDLE);
	origin.insert(sm.x, sm.y); //sets the origin point

	char userInput;
	do {
		std::cout << "press q to quit\n";
		std::cin >> userInput;
		userInput = tolower(userInput);
		sm.CheckState();
	} while (userInput != 'q');

	return 0;
}

void ChildOfStateMachine::CheckState() {
	switch(currentState){
		case IDLE:
			if (health < 50) SetRetreating(); //if we have less than 50 health then retreat
			else if (enemy.x == x || enemy.y == y) SetChasing(); //if the enemy is within our vertical or horizontal line of sight, and we have over 50 health
			break;
		case CHASING:
			if (health < 50) SetRetreating(); //if we have less than 50 health then retreat
			else if (enemy.x != x && enemy.y != y) SetIdle(); //if we lose sight of the enemy, and we have over 50 health, start idle
			break;
		case RETREATING:
			if (health > 50) SetIdle(); //if we have over 50 health, stop retreating and return to idling
			break;
		default:
			std::cout << "No state found for this state machine object\n";
			break;
	}
}

void ChildOfStateMachine::SetIdle() {
	SetState(IDLE);
	//set the behaviour for when in the idle state
}

void ChildOfStateMachine::SetChasing() {
	SetState(CHASING);
	//set the behaviour for when in the chasing state
}

void ChildOfStateMachine::SetRetreating() {
	SetState(RETREATING);
	//set the behaviour for when in the retreating state
}
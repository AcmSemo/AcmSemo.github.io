#include <iostream>

class StateMachine {
	public:
		enum State { NOT_ASSIGNED, IDLE, CHASING, RETREATING };
		State currentState = NOT_ASSIGNED;
		State previousState = NOT_ASSIGNED;
		StateMachine() = default;
		State GetCurrentState() { return currentState; }
		State GetPreviousState() { return previousState; }
		void SetState(State currentState);
		void SwitchToPreviousState(State currentState);
		virtual void CheckState(){};
};

void StateMachine::SetState(State currentState) {
	if (this->currentState != NOT_ASSIGNED) {
		this->previousState = this->currentState;
	}
	this->currentState = currentState;
}

void StateMachine::SwitchToPreviousState(State currentState) {
	if (this->previousState != NOT_ASSIGNED) {
		State temp = currentState;
		this->currentState = this->previousState;
		this->previousState = temp;
	}
}